const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();

// 設定中介軟體
app.use(cors());
app.use(express.json()); // 讓伺服器能看得懂前端傳來的 JSON 格式資料

// ================= 資料庫連線設定 =================
// 請確保你的 XAMPP MySQL 已經啟動
const db = mysql.createConnection({
    host: 'localhost',      // 資料庫主機 IP
    user: 'root',           // XAMPP 預設帳號
    password: '',           // XAMPP 預設密碼為空
    database: 'book_system' // 你之前建的資料庫名稱
});

// 測試資料庫是否連線成功
db.connect((err) => {
    if (err) {
        console.error('資料庫連線失敗：', err);
        return;
    }
    console.log('✅ MySQL 資料庫連線成功！');
});

// ================= API 路由設計 =================

// 1. 測試用 API (打開瀏覽器可以確認伺服器有在跑)
app.get('/', (req, res) => {
    res.send('二手書系統 Node.js 後端運作中！');
});

// 2. 登入 API (給 Android App 呼叫的)
app.post('/login', (req, res) => {
    // 取得前端傳過來的帳號密碼
    const { username, password } = req.body;

    // 準備 SQL 語法 (? 是為了防止 SQL Injection 攻擊)
    const sql = "SELECT * FROM users WHERE username = ? AND password = ?";

    // 執行查詢
    db.query(sql, [username, password], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: '資料庫錯誤', status: 'error' });
        }

        // 判斷有沒有找到符合的資料
        if (results.length > 0) {
            res.status(200).json({ message: `歡迎回來，${username}！`, status: 'success' });
        } else {
            res.status(401).json({ message: '帳號或密碼錯誤', status: 'fail' });
        }
    });
});

// 3. 註冊 API
app.post('/register', (req, res) => {
    const { username, password } = req.body;

    // 第一步：先檢查這個帳號是不是已經被註冊過了
    const checkSql = "SELECT * FROM users WHERE username = ?";
    db.query(checkSql, [username], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: '資料庫錯誤', status: 'error' });
        }

        if (results.length > 0) {
            // 如果查到資料，代表帳號已存在
            return res.status(409).json({ message: '此帳號已被註冊，請換一個', status: 'fail' });
        }

        // 第二步：如果帳號沒人用過，就把新帳號密碼存進資料庫
        const insertSql = "INSERT INTO users (username, password) VALUES (?, ?)";
        db.query(insertSql, [username, password], (err, insertResult) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ message: '註冊失敗', status: 'error' });
            }
            res.status(200).json({ message: '註冊成功！歡迎加入', status: 'success' });
        });
    });
});

// ================= 啟動伺服器 =================
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 伺服器已啟動於 http://localhost:${PORT}`);
});